#!/bin/bash
set -e

# clang-16 -O1 -S -emit-llvm main.c

mkdir binaries
for i in {1..256}; do
    data=$(python3 -c "import base64, hashlib; h=hashlib.sha256(b'$SECRET_SEED $i').digest(); print(base64.b64encode(h, altchars=b'{}').decode().replace('2','_')[:16 + h[-1] % 16])")
    opt-16 -load-pass-plugin ./libbw.so -passes="binary-watermark" -watermark-str $data main.ll >main.bc && clang-16 -O0 main.bc -o binaries/$i && strip binaries/$i
    echo $data >>binaries/results.txt
done
