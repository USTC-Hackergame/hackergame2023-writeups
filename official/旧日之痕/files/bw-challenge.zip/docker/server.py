results = set(open("binaries/results.txt").read().splitlines())
extracted = set()

while True:
    watermark = input("Give me extracted watermark: ")
    if watermark in results:
        extracted.add(watermark)
        if len(extracted) == 1:
            print(open("/flag1").read())
        elif len(extracted) == 100:
            print(open("/flag2").read())
        else:
            print(len(extracted))
    else:
        print("Nop")
