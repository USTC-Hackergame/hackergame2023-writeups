---
name: Add Lecture Notes
about: Add Lecture Notes
title: 'Lecture name [WIP] '
labels: wip
assignees: ''

---

Lecture: <Lecture # and name>
Notes by: <Author name>
Video lecture: <Link to lecture>
