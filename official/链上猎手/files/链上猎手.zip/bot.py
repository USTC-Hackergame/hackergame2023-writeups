from web3 import Web3
from web3.middleware import geth_poa_middleware
import time
import json
import logging
import sys
from collections import defaultdict
from eth_abi import encode

def show_eth(n):
    if n < 0:
        return '-' + show_eth(-n)
    return str(n // 10 ** 18) + '.' + '%018d' % (n % 10 ** 18) + ' ETH'

def process_block(block_number):
    token_to_pairs = defaultdict(list)
    for factory in factory1, factory2:
        count = factory.functions.allPairsLength().call(block_identifier=block_number)
        for i in range(count):
            pair_address = factory.functions.allPairs(i).call(block_identifier=block_number)
            pair = w3.eth.contract(abi=pair_abi, address=pair_address)
            token0 = pair.functions.token0().call(block_identifier=block_number)
            token1 = pair.functions.token1().call(block_identifier=block_number)
            if token0 == weth_address:
                token_to_pairs[token1].append(pair_address)
            elif token1 == weth_address:
                token_to_pairs[token0].append(pair_address)
    for token, pairs in token_to_pairs.items():
        if len(pairs) == 2:
            logging.info(f'Processing WETH -> {token} -> WETH, pairs={pairs}')
            try:
                process_pairs(token, *pairs)
            except Exception as e:
                logging.exception('Error processing pairs')

def getAmountOut(amountIn, reserveIn, reserveOut):
    return (amountIn * 997 * reserveOut) // (amountIn * 997 + reserveIn * 1000)

def maximum(f, low, high):
    mid = (low + high) // 2
    low_mid = (low + mid) // 2
    high_mid = (mid + high) // 2
    mid_v = f(mid)
    low_mid_v = f(low_mid)
    high_mid_v = f(high_mid)
    max_v = max(mid_v, low_mid_v, high_mid_v)
    min_v = min(mid_v, low_mid_v, high_mid_v)
    if max_v == low_mid_v:
        if low + 1 >= high:
            return low_mid
        return maximum(f, low, mid)
    if max_v == mid_v:
        if low + 1 >= high:
            return mid
        return maximum(f, low_mid, high_mid)
    if max_v == high_mid_v:
        if low + 1 >= high:
            return high_mid
        return maximum(f, mid, high)

def process_pairs(token, pair1_address, pair2_address):
    pair1 = w3.eth.contract(abi=pair_abi, address=pair1_address)
    pair2 = w3.eth.contract(abi=pair_abi, address=pair2_address)
    pair1reserve0, pair1reserve1, _ = pair1.functions.getReserves().call(block_identifier=block_number)
    pair2reserve0, pair2reserve1, _ = pair2.functions.getReserves().call(block_identifier=block_number)

    if pair1reserve0 == 0 or pair1reserve1 == 0 or pair2reserve0 == 0 or pair2reserve1 == 0:
        return

    if token.lower() < weth_address.lower():
        pair1reserveToken, pair1reserveWETH = pair1reserve0, pair1reserve1
        pair2reserveToken, pair2reserveWETH = pair2reserve0, pair2reserve1
        direction = True
    else:
        pair1reserveWETH, pair1reserveToken = pair1reserve0, pair1reserve1
        pair2reserveWETH, pair2reserveToken = pair2reserve0, pair2reserve1
        direction = False

    if pair1reserveWETH * pair2reserveToken > pair2reserveWETH * pair1reserveToken:
        pair1reserveWETH, pair1reserveToken, pair2reserveWETH, pair2reserveToken = pair2reserveWETH, pair2reserveToken, pair1reserveWETH, pair1reserveToken
        pair1_address, pair2_address = pair2_address, pair1_address
        pair1, pair2 = pair2, pair1

    def calc(amountIn):
        amountToken = getAmountOut(amountIn, pair1reserveWETH, pair1reserveToken)
        return amountToken, getAmountOut(amountToken, pair2reserveToken, pair2reserveWETH)

    def profit(amountIn):
        return calc(amountIn)[-1] - amountIn

    max_profit_input = maximum(profit, 1, 10 ** 18 * 100)
    amount1 = max_profit_input
    amount2, amount3 = calc(amount1)
    max_profit = amount3 - amount1

    logging.info('Max profit: %s (%s)', max_profit, show_eth(max_profit))

    if max_profit >= 10 ** 15:
        logging.info(f'Sending arbitrage transaction, amount1={amount1}, amount2={amount2}, amount3={amount3}, dir={direction}')
        nonce = w3.eth.get_transaction_count(acct.address)
        if challenge_id == 1:
            tx = bot.functions.arbitrage(pair1_address, pair2_address, amount1, amount2, amount3, direction).build_transaction(
                {'nonce': nonce, 'from': acct.address, 'gas': 10 ** 6, 'gasPrice': 10 ** 11}
            )
        elif challenge_id == 2:
            bot.functions.simulate(pair1_address, pair2_address, amount1, amount2, amount3, direction).call(
                {'nonce': nonce, 'from': acct.address, 'gas': 10 ** 6, 'gasPrice': 10 ** 11}
            )
            tx = bot.functions.arbitrage(pair1_address, pair2_address, amount1, amount2, amount3, direction).build_transaction(
                {'nonce': nonce, 'from': acct.address, 'gas': 10 ** 6, 'gasPrice': 10 ** 11}
            )
        elif challenge_id == 3:
            callback_calls = [
                (weth_address, weth.functions.transfer(pair1_address, amount1).build_transaction({'gas': 0, 'gasPrice': 0})['data']),
                (pair1_address, pair1.functions.swap(amount2 if direction else 0, 0 if direction else amount2, pair2_address, b'').build_transaction({'gas': 0, 'gasPrice': 0})['data']),
            ]
            callback_data = encode(['address[]', 'bytes[]'], [[call[0] for call in callback_calls], [bytes.fromhex(call[1][2:]) for call in callback_calls]])
            calls = [
                (pair2_address, pair2.functions.swap(0 if direction else amount3, amount3 if direction else 0, bot_address, callback_data).build_transaction({'gas': 0, 'gasPrice': 0})['data']),
            ]
            tx = bot.functions.arbitrage([call[0] for call in calls], [call[1] for call in calls]).build_transaction(
                {'nonce': nonce, 'from': acct.address, 'gas': 10 ** 6, 'gasPrice': 10 ** 11}
            )
        else:
            exit(-1)
        signed_tx = w3.eth.account.sign_transaction(tx, private_key=privatekey)
        tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
        tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        logging.info('Arbitrage transaction success: %s', tx_receipt.status)

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    bot_address = sys.argv[1]
    weth_address = sys.argv[2]
    factory1_address = sys.argv[3]
    factory2_address = sys.argv[4]
    challenge_id = int(sys.argv[5])

    w3 = Web3(Web3.IPCProvider('/dev/shm/geth/geth.ipc'))
    w3.middleware_onion.inject(geth_poa_middleware, layer=0)
    privatekey = open('bot_privatekey.txt').read().strip()
    acct = w3.eth.account.from_key(privatekey)

    _, factory_abi = json.load(open('uniswap-v2-factory.json'))
    factory1 = w3.eth.contract(abi=factory_abi, address=factory1_address)
    factory2 = w3.eth.contract(abi=factory_abi, address=factory2_address)

    _, pair_abi = json.load(open('uniswap-v2-pair.json'))
    _, bot_abi = json.load(open(f'bot{challenge_id}.json'))
    bot = w3.eth.contract(abi=bot_abi, address=bot_address)

    _, weth_abi = json.load(open('WETH.json'))
    weth = w3.eth.contract(abi=weth_abi, address=weth_address)

    last_block_number = None
    while True:
        block_number = w3.eth.block_number
        if block_number != last_block_number:
            logging.info('Got new block %s', block_number)
            try:
                process_block(block_number)
            except Exception as e:
                logging.exception('Error processing block')
            time.sleep(1)
        last_block_number = block_number
        time.sleep(0.1)
