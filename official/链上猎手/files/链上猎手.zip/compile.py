from solcx import compile_files
import json

for i in 1, 2, 3:
    compiled_sol = compile_files(
        f'contracts/bot{i}.sol',
        output_values=['abi', 'bin'],
        optimize=True,
        optimize_runs=999999,
        solc_version='0.8.21',
        evm_version='paris',
    )
    contract_interface = compiled_sol[f'contracts/bot{i}.sol:Bot']
    bytecode = contract_interface['bin']
    abi = contract_interface['abi']
    json.dump((bytecode, abi), open(f'bot{i}.json', 'w'))

compiled_sol = compile_files(
    'contracts/uniswap-v2-core/UniswapV2Factory.sol',
    output_values=['abi', 'bin'],
    optimize=True,
    optimize_runs=999999,
    solc_version='0.5.16',
)
contract_interface = compiled_sol['contracts/uniswap-v2-core/UniswapV2Factory.sol:UniswapV2Factory']
bytecode = contract_interface['bin']
abi = contract_interface['abi']
json.dump((bytecode, abi), open('uniswap-v2-factory.json', 'w'))

compiled_sol = compile_files(
    'contracts/uniswap-v2-core/UniswapV2Pair.sol',
    output_values=['abi', 'bin'],
    optimize=True,
    optimize_runs=999999,
    solc_version='0.5.16',
)
contract_interface = compiled_sol['contracts/uniswap-v2-core/UniswapV2Pair.sol:UniswapV2Pair']
bytecode = contract_interface['bin']
abi = contract_interface['abi']
json.dump((bytecode, abi), open('uniswap-v2-pair.json', 'w'))

compiled_sol = compile_files(
    'contracts/Deployer.sol',
    output_values=['abi', 'bin'],
    optimize=True,
    optimize_runs=999999,
    solc_version='0.8.21',
    evm_version='paris',
)
contract_interface = compiled_sol['contracts/Deployer.sol:Deployer']
bytecode = contract_interface['bin']
abi = contract_interface['abi']
json.dump((bytecode, abi), open('Deployer.json', 'w'))

compiled_sol = compile_files(
    'contracts/WETH.sol',
    output_values=['abi', 'bin'],
    optimize=True,
    optimize_runs=999999,
    solc_version='0.8.21',
    evm_version='paris',
)
contract_interface = compiled_sol['contracts/WETH.sol:WETH']
bytecode = contract_interface['bin']
abi = contract_interface['abi']
json.dump((bytecode, abi), open('WETH.json', 'w'))
