from web3 import Web3
from web3.middleware import geth_poa_middleware
import os
import json
import time
import shutil

def show_eth(n):
    if n < 0:
        return '-' + show_eth(-n)
    return str(n // 10 ** 18) + '.' + '%018d' % (n % 10 ** 18) + ' ETH'

challenge_id = int(input('The challenge you want to play (1 or 2 or 3): '))
assert challenge_id == 1 or challenge_id == 2 or challenge_id == 3

print('Launching geth...')
shutil.copytree('/data', '/dev/shm/geth')
os.system('geth --datadir /dev/shm/geth --nodiscover --mine --unlock 0x2537FC6C412bA4cD604804DA754099077bAaB458 --miner.etherbase 0x2537FC6C412bA4cD604804DA754099077bAaB458 --password password.txt --verbosity 0 --datadir.minfreedisk 0 &')
time.sleep(2)
w3 = Web3(Web3.IPCProvider('/dev/shm/geth/geth.ipc'))
w3.middleware_onion.inject(geth_poa_middleware, layer=0)
privatekey = open('privatekey.txt').read().strip()
acct = w3.eth.account.from_key(privatekey)

print('Deploying DEX factories...')
factories = []
for i in range(2):
    bytecode, abi = json.load(open('uniswap-v2-factory.json'))
    Factory = w3.eth.contract(abi=abi, bytecode=bytecode)
    nonce = w3.eth.get_transaction_count(acct.address)
    tx = Factory.constructor('0x0000000000000000000000000000000000000000').build_transaction({'nonce': nonce, 'from': acct.address})
    signed_tx = w3.eth.account.sign_transaction(tx, private_key=privatekey)
    tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    assert tx_receipt.status
    print(f'DEX factory{i + 1} address:', tx_receipt.contractAddress)
    factories.append(tx_receipt.contractAddress)

print('Deploying tokens, pairs and adding liquidity...')
bytecode, abi = json.load(open('Deployer.json'))
Deployer = w3.eth.contract(abi=abi, bytecode=bytecode)
nonce = w3.eth.get_transaction_count(acct.address)
tx = Deployer.constructor(*factories).build_transaction({'value': 10 ** 18 * 2, 'nonce': nonce, 'from': acct.address})
signed_tx = w3.eth.account.sign_transaction(tx, private_key=privatekey)
tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
assert tx_receipt.status
deployer = w3.eth.contract(abi=abi, address=tx_receipt.contractAddress)
print('Deployer address:', deployer.address)
_, abi = json.load(open('WETH.json'))
WETH = w3.eth.contract(abi=abi, address=deployer.functions.weth().call())
print('WETH address:', WETH.address)
print('Token address:', deployer.functions.token().call())
print('Pair1 address:', deployer.functions.pair1().call())
print('Pair2 address:', deployer.functions.pair2().call())

print('Deploying bot contract...')
bot_privatekey = open('bot_privatekey.txt').read().strip()
bot_acct = w3.eth.account.from_key(bot_privatekey)
print('Bot owner address:', bot_acct.address)
bytecode, abi = json.load(open(f'bot{challenge_id}.json'))
Bot = w3.eth.contract(abi=abi, bytecode=bytecode)
nonce = w3.eth.get_transaction_count(bot_acct.address)
if challenge_id == 1:
    tx = Bot.constructor(WETH.address, *factories).build_transaction({'value': 10 ** 18, 'nonce': nonce, 'from': bot_acct.address})
else:
    tx = Bot.constructor(WETH.address).build_transaction({'value': 10 ** 18, 'nonce': nonce, 'from': bot_acct.address})
signed_tx = w3.eth.account.sign_transaction(tx, private_key=bot_privatekey)
tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
assert tx_receipt.status
bot_address = tx_receipt.contractAddress
print('Bot contract address:', bot_address)
print()

print('Starting MEV Bot...')
os.system(f'python3 bot.py {bot_address} {WETH.address} {factories[0]} {factories[1]} {challenge_id} &')
time.sleep(5)
while True:
    print()
    print('-' * 50)
    print('1. Get free ETH')
    print('2. Send raw transaction')
    print('3. Get flag')
    print('4. Exit')
    choice = int(input('Choice: '))
    if choice == 1:
        address = input('Address: ')
        address = Web3.to_checksum_address(address)
        nonce = w3.eth.get_transaction_count(acct.address)
        signed_tx = w3.eth.account.sign_transaction({'to': address, 'value': 10 ** 18, 'nonce': nonce, 'gas': 21000, 'gasPrice': 10 ** 11, 'chainId': 2023}, private_key=privatekey)
        tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
        tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        assert tx_receipt.status
        balance = w3.eth.get_balance(address)
        print(f'Balance of {address}: {show_eth(balance)}')
        time.sleep(5)
    elif choice == 2:
        raw_tx = bytes.fromhex(input('Raw transaction: ')[2:])
        tx_hash = w3.eth.send_raw_transaction(raw_tx)
        tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        print('Transaction receipt:', tx_receipt)
        time.sleep(5)
    elif choice == 3:
        bot_balance = WETH.functions.balanceOf(bot_address).call()
        print('Balance of bot contract:', show_eth(bot_balance))
        if bot_balance == 0:
            print(open(f'flag{challenge_id}').read())
        else:
            print('Balance > 0, no flag')
    elif choice == 4:
        break
